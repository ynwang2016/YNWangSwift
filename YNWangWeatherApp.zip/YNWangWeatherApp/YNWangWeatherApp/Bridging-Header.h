//
//  Bridging-Header.h
//  YNWangWeatherApp
//
//  Created by ynwang on 16/11/3.
//  Copyright © 2016年 ynwang. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h

#import "AFNetworking.h"


#define YNWidth self.contentView.frame.size.width

#endif /* Bridging_Header_h */
